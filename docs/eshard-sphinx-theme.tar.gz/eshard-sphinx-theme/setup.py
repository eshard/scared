from setuptools import setup

setup(
    name='eshard_sphinx_theme',
    version='0.1',
    description='Sphinx theme used by eshard.',
    long_description=open('README.rst').read(),
    author='Tiana RAZAFINDRALAMBO',
    author_email='tiana.razafindralambo@eshard.com',
    url='https://gitlab.eshard.int/eshard/eshard-sphinx-theme',
    packages=['eshard_sphinx_theme'],
    include_package_data=True,
    install_requires=['Sphinx>1.3'],
    classifiers=(
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Natural Language :: English',
        'Programming Language :: Python',
    ),
)
