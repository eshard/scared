eshard sphinx theme
==================

Installation
############

python setup.py install

Configuration
#############

======================
Minimum configuration
======================

Add the following to your conf.py:

.. code-block:: python

    import eshard_sphinx_theme

    extensions = [  'sphinx.ext.autodoc',
                    ....
                    'eshard_sphinx_theme'
    ]

    html_translator_class = 'eshard_sphinx_theme.HTMLTranslator'
    html_theme_path = eshard_sphinx_theme.html_theme_path()
    html_theme = 'eshard_sphinx_theme'


    # eshard theme options (see theme.conf for more information)
    html_theme_options = {
        # Set the name of the project to appear in the sidebar
        "project_nav_name": "Project Name",
    }

======================
!!!WARNING!!!
======================
If the following lines are present in your conf.py file, they must be removed/commented:

.. code-block:: python

    html_sidebars = {
        '**': [
            'about.html',
            'navigation.html',
            'relations.html',  # needs 'show_related': True theme option to display
            'searchbox.html',
            'donate.html',
        ]
    }
    

======================
Extra configuration
======================

More options can be passed:

.. code-block:: python

    # eshard theme options (see theme.conf for more information)
    html_theme_options = {

        # Set the path to a special layout to include for the homepage
        "index_template": "special_index.html",

        # Set the name of the project to appear in the left sidebar.
        "project_nav_name": "Project Name",

        # Set your Disqus short name to enable comments
        "disqus_comments_shortname": "my_disqus_comments_short_name",

        # Set you GA account ID to enable tracking
        "google_analytics_account": "my_ga_account",

        # Path to a touch icon
        "touch_icon": "",

        # Specify a base_url used to generate sitemap.xml links. If not
        # specified, then no sitemap will be built.
        "base_url": ""

        # Allow a separate homepage from the master_doc
        "homepage": "index",

        # Allow the project link to be overriden to a custom URL.
        "projectlink": "http://myproject.url",
    }
